<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=ro_new',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
//     'dsn' => 'mysql:host=db-mysql-sgp1-00251-do-user-8688738-0.b.db.ondigitalocean.com;port=25060;dbname=tvet',
//     'username' => 'doadmin',
//     'password' => 'xz7jeh5rrm3wjlot',
//     'charset' => 'utf8',
//     'attributes' => [
// 		// PDO::MYSQL_ATTR_SSL_KEY => dirname(dirname(__DIR__)) . '/common/config/ssl/client-key.pem',
// 		PDO::MYSQL_ATTR_SSL_CERT => 'ca-certificate.crt',                
// 		// PDO::MYSQL_ATTR_SSL_CA => dirname(dirname(__DIR__)) . '/common/config/ssl/server-ca.pem',                
// 		],

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
